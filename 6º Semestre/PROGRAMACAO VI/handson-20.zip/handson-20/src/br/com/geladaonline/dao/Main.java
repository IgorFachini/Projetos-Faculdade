package br.com.geladaonline.dao;

public class Main {
	public static void main(String[] args) {
		new JPAUtil().getEntityManager();
	}
}