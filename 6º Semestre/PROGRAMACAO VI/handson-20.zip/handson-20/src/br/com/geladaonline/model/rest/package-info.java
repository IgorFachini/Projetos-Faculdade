

@XmlJavaTypeAdapter(value=JaxbAdapter.class)
package br.com.geladaonline.model.rest;

import javax.ws.rs.core.Link.JaxbAdapter;
import javax.xml.bind.annotation.adapters.XmlJavaTypeAdapter;
