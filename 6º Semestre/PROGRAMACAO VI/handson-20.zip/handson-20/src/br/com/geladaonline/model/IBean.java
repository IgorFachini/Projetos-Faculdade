package br.com.geladaonline.model;

public interface IBean {

	Long getId();
	void setId(Long id);
}
