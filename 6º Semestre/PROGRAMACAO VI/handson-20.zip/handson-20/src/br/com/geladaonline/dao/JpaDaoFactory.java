package br.com.geladaonline.dao;

public class JpaDaoFactory {

	public static JpaDaoFactory instance = new JpaDaoFactory();
	
	private CervejaDao cervejaDao;
	

	private JpaDaoFactory() {}
		
	public static JpaDaoFactory getInstance(){
		return instance;
	}
	
	
	public CervejaDao getCervejaDao(){
		if(this.cervejaDao == null)
			this.cervejaDao = new CervejaDao();
		return this.cervejaDao;
	}

}
