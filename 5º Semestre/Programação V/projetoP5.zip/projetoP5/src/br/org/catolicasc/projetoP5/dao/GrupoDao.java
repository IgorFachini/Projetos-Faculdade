package br.org.catolicasc.projetoP5.dao;

import br.org.catolicasc.projetoP5.entity.Grupo;

public class GrupoDao extends JpaDaoBase<Grupo>{

}
