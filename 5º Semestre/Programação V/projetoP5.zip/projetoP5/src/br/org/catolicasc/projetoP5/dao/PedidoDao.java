package br.org.catolicasc.projetoP5.dao;

import br.org.catolicasc.projetoP5.entity.Pedido;

public class PedidoDao extends JpaDaoBase<Pedido> {

}
