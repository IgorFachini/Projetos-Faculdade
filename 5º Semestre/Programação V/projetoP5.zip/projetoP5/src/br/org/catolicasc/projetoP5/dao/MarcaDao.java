package br.org.catolicasc.projetoP5.dao;

import br.org.catolicasc.projetoP5.entity.Marca;

public class MarcaDao extends JpaDaoBase<Marca> {

}
