package br.org.catolicasc.projetoP5.dao;

import br.org.catolicasc.projetoP5.entity.Automovel;

public class AutomovelDao extends JpaDaoBase<Automovel> {

}
