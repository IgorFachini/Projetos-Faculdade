package br.org.catolicasc.projetoP5.dao;

import br.org.catolicasc.projetoP5.entity.Produto;

public class ProdutoDao extends JpaDaoBase<Produto> {

}
