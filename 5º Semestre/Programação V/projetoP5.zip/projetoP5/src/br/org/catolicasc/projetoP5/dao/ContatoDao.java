package br.org.catolicasc.projetoP5.dao;

import br.org.catolicasc.projetoP5.entity.Contato;

public class ContatoDao extends JpaDaoBase<Contato>{

}
