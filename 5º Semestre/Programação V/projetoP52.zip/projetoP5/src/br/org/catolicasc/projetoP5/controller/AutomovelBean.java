package br.org.catolicasc.projetoP5.controller;

import java.util.List;

import javax.faces.application.FacesMessage;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.ViewScoped;
import javax.faces.context.FacesContext;

import br.org.catolicasc.projetoP5.dao.AutomovelDao;
import br.org.catolicasc.projetoP5.entity.Automovel;


@ViewScoped
@ManagedBean
public class AutomovelBean {

	private Automovel automovel = new Automovel();
	private AutomovelDao automovelDao = new AutomovelDao();
	
	public List<Automovel> getAutomoveis() {
		return this.automovelDao.listaTodos();
	}

	public Automovel getAutomovel() {
		return automovel;
	}

	public void setAutomovel(Automovel automovel) {
		this.automovel = automovel;
	}

	public String salva() {
		this.automovelDao.salva(this.automovel);
		this.automovel = new Automovel();
		FacesMessage msg = new FacesMessage("Automovel salvo com sucesso!");
		FacesContext.getCurrentInstance().addMessage(null, msg);
		
		return "listar";
	}

	public void exclui(Automovel automovel) {
		this.automovelDao.remove(automovel);
	}

	public String edita(Automovel automovel) {
		this.automovel = automovel;
		return "cadastraAutomoveis.xhtml";

	}	
}
