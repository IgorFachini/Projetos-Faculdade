package br.org.catolicasc.projetoP5.dao;

import br.org.catolicasc.projetoP5.entity.Modelo;

public class ModeloDao extends JpaDaoBase<Modelo> {

	
	
}
