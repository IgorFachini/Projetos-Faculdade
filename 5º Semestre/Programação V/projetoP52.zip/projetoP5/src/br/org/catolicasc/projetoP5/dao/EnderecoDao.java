package br.org.catolicasc.projetoP5.dao;

import br.org.catolicasc.projetoP5.entity.Endereco;

public class EnderecoDao extends JpaDaoBase<Endereco>{

}
