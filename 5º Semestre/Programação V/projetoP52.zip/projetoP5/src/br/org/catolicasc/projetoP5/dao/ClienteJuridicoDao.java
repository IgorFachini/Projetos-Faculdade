package br.org.catolicasc.projetoP5.dao;

import br.org.catolicasc.projetoP5.entity.ClienteJuridico;

public class ClienteJuridicoDao extends JpaDaoBase<ClienteJuridico> {

}
