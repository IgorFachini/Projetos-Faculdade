package br.org.catolicasc.projetoP5.interfaces;

public interface Bean {

	Long getId();
	void setId(Long id);
}
