package br.org.catolicasc.projetoP5.controller;

import java.util.List;

import javax.annotation.PostConstruct;
import javax.faces.bean.ManagedBean;

import br.org.catolicasc.projetoP5.dao.ModeloDao;
import br.org.catolicasc.projetoP5.entity.Modelo;


@ManagedBean
public class ModeloBean  {
	private Modelo modelo;
	private ModeloDao modeloDao = new ModeloDao();

	@PostConstruct
	public void init() {
		modelo = new Modelo();
	}

	public void salva() {
		modeloDao.salva(modelo);
		this.novo();
	}

	public List<Modelo> getModelos() {
		return this.modeloDao.listaTodos();
	}

	public Modelo getModelo() {
		return this.modelo;
	}

	public void setModelo(Modelo modelo) {
		this.modelo = modelo;
	}

	public void edita(Modelo modelo) {
		this.setModelo(modelo);
	}

	public void exclui(Modelo modelo) {
		this.modeloDao.remove(modelo);
	}

	public void novo() {
		this.modelo = new Modelo();
	}

}
