package br.org.catolicasc.projetoP5.dao;

import br.org.catolicasc.projetoP5.entity.ClienteFisico;

public class ClienteFisicoDao extends JpaDaoBase<ClienteFisico> {

}
