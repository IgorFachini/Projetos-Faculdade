package br.org.catolicasc.projetoP5.controller;

import java.util.List;

import javax.faces.bean.ManagedBean;
import javax.faces.bean.ViewScoped;

import br.org.catolicasc.projetoP5.dao.MarcaDao;
import br.org.catolicasc.projetoP5.entity.Marca;



@ViewScoped
@ManagedBean
public class MarcaBean {

	private MarcaDao marcaDao = new MarcaDao();
	private Marca marca = new Marca();
	
		
	public List<Marca> getMarcas() {
		return this.marcaDao.listaTodos();
	}
	
	public Marca getMarca() {
		return marca;
	}
	
	public String cria(){
		this.marca = new Marca();
		return "editar";
	}

	public String edita(Marca marca){
		this.marca =marca;
		return "editar";
	}
	
	public void setMarca(Marca marca) {
		this.marca = marca;
	}

	public String salva() {
		try {
			this.marcaDao.salva(this.marca);
			this.marca = new Marca();
			return "listar";
		} catch (Exception e) {
			return "erro";

		}
	}
}
